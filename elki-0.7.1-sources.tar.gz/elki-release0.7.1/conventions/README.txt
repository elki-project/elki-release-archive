enable project specific settings for eclipse users:

code formatter: import elkiformatter.xml

compiler error settings: copy/overwrite corresponding line of error-settings.txt into
.settings/org.eclipse.jdt.core.prefs (replace line beginning with org.eclipse.jdt.core.compiler.)