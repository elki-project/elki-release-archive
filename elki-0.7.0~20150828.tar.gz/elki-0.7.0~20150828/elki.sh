#!/bin/sh
exec java -cp "elki/*:dependency/*" de.lmu.ifi.dbs.elki.application.ELKILauncher "$@"
