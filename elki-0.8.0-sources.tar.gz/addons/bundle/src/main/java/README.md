To access the ELKI source code, please use the individual modules
(elki, elki-batik-visualization etc.)
instead of the "single jar bundle".
